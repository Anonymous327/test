
libMatrix.dll is a little win32 matrix processing library
created 2008-12-07 by madshi.net

this lib is based on pro_optimizer's (Christian Kothe) foobar2000 plugins
below you'll find the original description by Christian Kothe

Christian Kothe allowed me to use his code for eac3to under LGPL instead of GPL
this permission is limited to eac3to and does not extend to any other software
if you want to use libMatrix under LGPL, too, you'll have to contact C. Kothe

this lib uses the Fast Fourier Transform (FTW) functions by Takuya Ooura
http://www.kurims.kyoto-u.ac.jp/~ooura/index.html

-------------------------------------------------------------------------------

Copyright (C) 2007 Christian Kothe

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
